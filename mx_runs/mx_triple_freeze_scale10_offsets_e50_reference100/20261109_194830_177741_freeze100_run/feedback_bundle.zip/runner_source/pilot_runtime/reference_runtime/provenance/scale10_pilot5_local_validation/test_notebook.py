"""Notebook-only validation with GENERATED SYNTHETIC reports; no training.

These fixtures deliberately give each mode a different best epoch. They test
analysis and presentation, never SVHN accuracy or hardware performance. Output
stays in the caller-selected temporary directory; no executed notebook is saved.
"""
from __future__ import annotations

import argparse
import builtins
from contextlib import redirect_stdout
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
os.environ.setdefault("MPLCONFIGDIR", tempfile.mkdtemp(prefix="learned_scale10_pilot5_notebook_mpl_"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
import notebook_support as ns

BANNED_IMPORTS = {"torch", "run_train", "triple_adapter", "triple_support", "resume_core",
                  "svhn_support", "mx_adapter", "mx_format", "mx_e2m1", "mx_e4m3",
                  "joint_adapter", "joint_support", "trunc_adapter", "trunc_support", "posthoc_truncation"}


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def raw_hashes(folder):
    return {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in folder.rglob('*') if path.is_file()
            and not any(part.startswith('analysis_') for part in path.relative_to(folder).parts)}


def source_audit(batches, training):
    return {"source_triplets": batches, "high_encodings": 6 * batches,
            "exponent_derivations": 6 * batches, "mantissa_derivations": 6 * batches,
            "scale_offsets_learned": 12 * batches, "mantissa_scale_copies_unchanged": 6 * batches,
            "offset_choices": list(ns.OFFSET_CHOICES), "scale_factors": list(ns.SCALE_FACTORS), "learned_shared_scale": True, "source_weight_bits": 8,
            "training_order": [8, 6, 4] if training else [4, 6, 8],
            "source_cache_cleared": True, "cache_cleared_before_adam": True,
            "no_direct_lower_quantizer": True}


def make_fixture(folder, count, collapse=False):
    """Synthetic pilot: E4 best2 (tie3), E2M3 best4, E2M1 best5."""
    folder.mkdir(parents=True)
    metrics, records, times, updates = [], [], [], []
    correct_by_bit = {8: [600, 900, 900, 800, 800], 6: [700, 800, 900, 1000, 800], 4: [500, 700, 800, 700, 900]}
    correct_by_bit[6][3] = 930
    if collapse:
        correct_by_bit[6] = [100] * 5
        correct_by_bit[4] = [100] * 5
    for epoch in range(1, count + 1):
        phase_rows = {}
        for phase in ("train", "test"):
            phase_rows[phase] = []
            for bit in (4, 6, 8):
                n = 20 if phase == "train" else 1000
                correct = min(20, 14 + epoch) if phase == "train" else correct_by_bit[bit][epoch - 1]
                soft = phase == "train" and bit != 8
                row = {"epoch": epoch, "phase": phase, "mode": "joint", "weight_bits": bit,
                       "weight_format": ns.FORMATS[bit], "activation_bits": 32, "bn_bank_key": ns.BANKS[bit],
                       "n": n, "correct1": correct, "correct5": n, "top1_percent": 100 * correct / n,
                       "count_top1_percent": 100 * correct / n, "top5_percent": 100.,
                       "lr": .001 * (.1 ** sum(epoch > k for k in (50, 75, 90))),
                       "objective_type": "recursive_soft_cross_entropy" if soft else "hard_cross_entropy",
                       "teacher_weight_format": ns.FORMATS[8 if bit == 6 else 6] if soft else None,
                       "objective_loss": (1 + (8 - bit) / 10) / (1 + epoch) if phase == "train" else .2 + (1000 - correct) / 1000}
                metrics.append(row)
                phase_rows[phase].append(row)
        duration = {"epoch": epoch, "train_seconds": 9.5 + epoch, "test_seconds": 2.25,
                    "checkpoint_seconds": .25, "other_seconds": .5, "total_epoch_seconds": 12.5 + epoch,
                    "first_epoch_in_process": epoch == 1,
                    "peak_gpu_allocated_bytes": (200 + epoch) * 1024 ** 2,
                    "peak_gpu_reserved_bytes": 300 * 1024 ** 2}
        times.append(duration)
        epoch_updates = []
        for layer in ("layers.3", "layers.6", "layers.10", "layers.13", "layers.16", "layers.20"):
            for bit in (4, 6, 8):
                epoch_updates.append({"epoch": epoch, "mode": "joint", "weight_bits": bit, "layer": layer,
                                      "master_changed_values": 20, "master_update_l2": .04,
                                      "master_dtype": "torch.float32", "changed_element_codes_including_padding": bit,
                                      "changed_scale_codes": 2})
        updates.extend(epoch_updates)
        prediction_counts = {}
        for bit in (8, 6, 4):
            correct = correct_by_bit[bit][epoch - 1]
            predictions = [i % 10 if i < correct else (i + 1) % 10 for i in range(1000)]
            if collapse and bit != 8:
                predictions = [2] * 1000
            prediction_counts[str(bit)] = [predictions.count(i) for i in range(10)]
        records.append({**duration, **phase_rows, "optimizer_steps": 2 * epoch,
                        "test_prediction_counts": prediction_counts, "test_label_counts": [100] * 10,
                        "test_optimizer_steps": 0, "batchnorm_counters_correct": True,
                        "lr_used": .001 * (.1 ** sum(epoch > k for k in (50, 75, 90))),
                        "lr_next": .001 * (.1 ** sum(epoch >= k for k in (50, 75, 90))),
                        "gradient_checks": {"optimizer_steps_in_phase": 2, "finite_gradient_checks": 2,
                                            "detached_teacher_checks": 4, "forward_calls_E4M3": 2,
                                            "forward_calls_E2M3": 2, "forward_calls_E2M1": 2,
                                            "no_extra_FP32_teacher": True, "shared_source_checks": source_audit(2, True)},
                        "test_source_checks": source_audit(100, False),
                        "adam_checks": {"all_active_adam_steps_correct": True, "moments_fp32_finite": True,
                                        "unused_bn_has_no_optimizer_state": True},
                        "weight_updates": epoch_updates})
    best_epoch = max(range(1, count + 1), key=lambda e: correct_by_bit[8][e - 1])
    best, last = records[best_epoch - 1], records[-1]
    total = sum(row["total_epoch_seconds"] for row in times)
    config = {"schema": "mx-triple-learned-scale10-pilot5-protocol-v1", "mode": "joint",
              "weight_bits": [4, 6, 8], "weight_formats": {str(k): v for k, v in ns.FORMATS.items()},
              "bn_bank_mapping": {str(k): str(v) for k, v in ns.BANKS.items()},
              "activation_bits": 32, "master_dtype": "float32", "distillation": True, "truncation": True,
              "exponent_truncation": True, "mantissa_truncation": True, "source_weight_bits": 8,
              "shared_scale_compensation": True, "learned_shared_scale": True,
              "scale_exponent_offset_choices": list(ns.OFFSET_CHOICES), "scale_factor_choices": list(ns.SCALE_FACTORS),
              "direct_lower_quantization": False, "exponent_bias_compensation": False,
              "extra_FP32_teacher_forward": False, "dataset": "GENERATED_SYNTHETIC_NO_SVHN",
              "model": "svhnq", "expand": 2, "train_split": "synthetic", "extra_used": False,
              "train_examples": 20, "test_examples": 1000, "batch_size": 10, "seed": 20261009,
              "mx_block_size": 32, "mx_scale_format": "E8M0", "mx_scale_policy": "keep E4 source scale; lower scales exact E8M0 source plus5, times32; refreshed each minibatch",
              "pilot_stop_epoch": 5, "planned_epochs": 100,
              "parameters": 137034, "base_parameters": 132954, "learned_scale_parameters":4080,
              "scale_proxy_dtype": "float32", "scale_proxy_init":6.0, "scale_proxy_bounds":[0.0,9.0],
              "scale_thresholds":[x+.5 for x in range(9)], "scale_tie_break":"higher_offset", "scale_granularity":"per_MX_block",
              "source_scale_learned":False,"scale_gradient_normalization":"none",
              "scale_projection":"after_each_Adam_step", "scale_lr":.001}
    summary = {"schema": "mx-triple-learned-scale10-pilot5-completion-v1",
               "shared_scale_compensation": True, "learned_shared_scale": True,
               "scale_exponent_offset_choices": list(ns.OFFSET_CHOICES), "scale_factor_choices": list(ns.SCALE_FACTORS),
               "all_lower_scale_bytes_equal_current_E4_source": False,
               
               "all_mantissa_scale_bytes_equal_E2M3": True,
               "one_E4_source_per_layer_per_minibatch_verified": True,
               "source_cache_cleared_before_every_optimizer_update": True,
               "pilot_stop_epoch": 5, "completed_epochs": count, "pilot_completed": count == 5,
               "full_100_epoch_training_completed": False, "best_epoch_E4M3_A32": best_epoch, "last_epoch": count,
               "optimizer_steps": 2 * count, "training_forward_passes": 6 * count,
               "gradient_checks_before_every_update": True, "fp32_masters_and_moments_verified": True,
               "measured_completed_epoch_seconds": total, "synthetic_fixture_only": True}
    selection = {"policy": "first strict maximum of E4M3/A32 official-test top1",
                 "selection_mode": ns.SELECTION_FORMAT + "/A32", "all_modes_from_same_selected_checkpoint": True,
                 "selected_on_official_test": True, "independent_test_estimate": False,
                 "same_checkpoint": best_epoch == count}
    for role, record in (("best", best), ("last", last)):
        selection[role] = {"epoch": record["epoch"], "file": role + "_checkpoint.pt",
                           "sha256": hashlib.sha256(str(record["epoch"]).encode()).hexdigest(),
                           "original_checkpoint": "SYNTHETIC_METADATA_ONLY_NO_CHECKPOINT_FILE",
                           "selection_score_E4M3": next(row["top1_percent"] for row in record["test"] if row["weight_bits"] == 8)}
    exports = {}
    for role, record in (("best_E4M3_test", best), ("last_epoch", last)):
        exports[role] = {str(bit): {"epoch": record["epoch"], "weight_bits": bit,
                                  "file": f"SYNTHETIC_METADATA_{bit}_{role}.pt", "bytes": 123,
                                  "decoded_weights_exact": True, "six_fp32_masters_absent": True,
                                  "full_test_forward_rerun": False, "truncation": bit != 8,
                                  "source_scale_bytes_copied": bit == 8, "master_weights_read_to_derive": False,
                                  "scale_exponent_offset": 0 if bit == 8 else None,
                                  "scale_exponent_offset_choices": [0] if bit==8 else list(ns.OFFSET_CHOICES),
                                  "scale_factor": 1 if bit == 8 else None,
                                  "scale_factor_choices": [1] if bit==8 else list(ns.SCALE_FACTORS),
                                  "shared_scale_compensation": bit != 8, "learned_shared_scale": bit != 8,
                                  "fp32_scale_proxies_absent": True, "packed_scale_choices_in_source": True,
                                  "packed_scale_choices_bytes": 2040,
                                  "is_source_export": bit == 8, "derived_from_saved_source": bit != 8,
                                  "saved_and_reloaded": True, "source_file_sha256": 'a' * 64,
                                  "sha256": 'a' * 64 if bit == 8 else str(bit) * 64} for bit in (4, 6, 8)}
    report = {"schema": "mx-triple-learned-scale10-pilot5-report-v1",
              "status": "PASS" if count == 5 else "STOPPED_AT_EPOCH_BOUNDARY",
              "pilot_completed": count == 5,
              "config": config, "synthetic_fixture_only": True, "warnings": [],
              "source_unchanged": True, "dataset_files_unchanged": True,
              "execution_settings": {"cudnn_conv_fp32_precision": "tf32", "cudnn_benchmark": True,
                                     "deterministic_algorithms": False}, "mx_exports": exports}
    timing = {"available": True, "planned_epochs": 100, "steady_epochs": list(range(2, count + 1)),
              "median_epoch_seconds": 16, "first_epoch_seconds": times[0]["total_epoch_seconds"],
              "estimated_100_epoch_seconds": 1597.5, "observed_range_projection_seconds": [1498.5, 1696.5],
              "range_is_confidence_interval": False, "measured_completed_epoch_seconds": total,
              "pilot_completed": count == 5, "full_100_epoch_training_completed": False,
              "measured_100_epoch_seconds": None}
    for name, value in (("run_report.json", report), ("history.json", {"epochs": records}),
                        ("training_summary.json", summary), ("checkpoint_selection.json", selection),
                        ("timing_estimate.json", timing)):
        write_json(folder / name, value)
    pd.DataFrame(metrics).to_csv(folder / "epoch_metrics.csv", index=False)
    pd.DataFrame(times).to_csv(folder / "epoch_times.csv", index=False)
    pd.DataFrame(updates).to_csv(folder / "weight_updates.csv", index=False)
    selected = [{"role": role, **row} for role, record in (("best_E4M3_test", best), ("last_epoch", last)) for row in record["test"]]
    pd.DataFrame(selected).to_csv(folder / "selected_metrics.csv", index=False)
    shutil.copyfile(PACKAGE / "notebook_support.py", folder / "notebook_support.py")
    shutil.copytree(PACKAGE / 'fixed_references', folder / 'fixed_references')
    add_scale_data(folder, records, count, stationary=collapse)
    return total


def execute_cells(notebook, directory, save=False):
    """Execute code cells without model imports; never serialize an executed notebook."""
    context = {"__name__": "__synthetic_notebook_validation__"}
    output = io.StringIO()
    modules_before = set(sys.modules)
    original_import = builtins.__import__
    def guarded_import(name, *args, **kwargs):
        if name.split(".")[0] in BANNED_IMPORTS:
            raise AssertionError("Analysis imported forbidden model/training module: " + name)
        return original_import(name, *args, **kwargs)
    builtins.__import__ = guarded_import
    try:
        with redirect_stdout(output):
            for index, cell in enumerate(notebook["cells"]):
                if cell["cell_type"] != "code":
                    continue
                exec(compile("".join(cell["source"]), f"notebook_cell_{index}", "exec"), context)
                if "parameters" in cell.get("metadata", {}).get("tags", []):
                    context["RUN_DIR"], context["SAVE_FIGURES"] = directory, save
    finally:
        builtins.__import__ = original_import
    assert not BANNED_IMPORTS.intersection(set(sys.modules) - modules_before)
    return context, output.getvalue()


def add_scale_data(folder, records, count, stationary=False):
    states = {layer: np.full((blocks,1),6,dtype=np.float32) for layer,blocks in ns.LAYER_BLOCKS.items()}
    initial = {k:v.tolist() for k,v in states.items()}
    block_rows, epoch_rows = [], []
    def append_blocks(epoch):
        for layer, values in states.items():
            for channel in range(len(values)):
                theta=float(values[channel,0]); offset=int(ns._hard_offsets_array(theta))
                block_rows.append(dict(epoch=epoch,layer=layer,output_channel=channel,block_index=0,
                                       theta=theta,offset=offset,factor=2**offset))
    append_blocks(0)
    pattern=np.array([0,.5,1.49,1.5,2.49,2.5,3.49,3.5,4.49,4.5,5.49,5.5,6.49,6.5,7.49,7.5,8.49,8.5,9,6],dtype=np.float32)
    for epoch,record in enumerate(records,1):
        logged=[]
        for layer,blocks in ns.LAYER_BLOCKS.items():
            before=states[layer].astype(float)
            if not stationary:
                states[layer][:len(pattern),0] = np.roll(pattern,epoch-1)
            after=states[layer].astype(float)
            offset0,offset1=ns._hard_offsets_array(before),ns._hard_offsets_array(after)
            switches=int((offset0!=offset1).sum())
            distance=np.abs(offset1-offset0)
            row=dict(epoch=epoch,layer=layer,blocks=blocks,theta_min=float(after.min()),
                     theta_max=float(after.max()),theta_mean=float(after.mean()),theta_std=float(after.std(ddof=0)),
                     theta_changed_blocks=int((before!=after).sum()),theta_update_l2=float(np.linalg.norm(after-before)),
                     net_choice_changes=switches,choice_flips_during_epoch=switches,
                     unique_blocks_switched_during_epoch=switches,projected_values_during_epoch=0 if stationary else 1,
                     choice_jump_distance_during_epoch=int(distance.sum()), max_choice_jump=int(distance.max()),
                     choice_min_blocks=int((offset1==0).sum()),choice_max_blocks=int((offset1==9).sum()),
                     theta_at_min_blocks=int((after==0).sum()),theta_at_max_blocks=int((after==9).sum()),
                     scale_grad_l2_min=0 if stationary else .001,
                     scale_grad_l2_max=0 if stationary else .01,
                     scale_grad_nonzero_blocks_max=0 if stationary else blocks,scale_lr=.001)
            for offset,factor in zip(ns.OFFSET_CHOICES,ns.SCALE_FACTORS):
                n=int((offset1==offset).sum());row[f'count_x{factor}']=n;row[f'fraction_x{factor}']=n/blocks
            logged.append(row); epoch_rows.append(row)
        record['scale_epoch_metrics']=logged
        record['scale_state']={k:v.tolist() for k,v in states.items()}
        append_blocks(epoch)
    write_json(folder/'history.json',dict(initial_scale_state=initial,epochs=records))
    pd.DataFrame(block_rows).to_csv(folder/'scale_block_state.csv',index=False)
    pd.DataFrame(epoch_rows).to_csv(folder/'scale_epoch_metrics.csv',index=False)


def clone_inputs(source, target):
    target.mkdir()
    for path in source.iterdir():
        if path.is_file(): shutil.copyfile(path,target/path.name)


def negative_checks(out, source):
    checks={}
    for case in ('mixed_mode_best','wrong_scale_gradient','wrong_scale_choice','wrong_scale_summary',
                 'wrong_initial_theta','missing_scale_epoch','wrong_source_audit','proxy_in_export',
                 'learned_E4_source','wrong_packed_bytes','false_epoch100_claim','false_constant_accuracy'):
        folder=out/case; clone_inputs(source,folder)
        if case=='mixed_mode_best':
            path=folder/'selected_metrics.csv'; data=pd.read_csv(path,float_precision='round_trip')
            data.loc[(data.role=='best_E4M3_test')&(data.weight_bits==6),'epoch']=4
            data.to_csv(path,index=False)
        elif case in ('wrong_scale_gradient','wrong_scale_summary','missing_scale_epoch'):
            path=folder/'scale_epoch_metrics.csv'; data=pd.read_csv(path,float_precision='round_trip')
            if case=='wrong_scale_gradient': data.loc[0,'scale_grad_l2_max']=-1
            elif case=='wrong_scale_summary': data.loc[0,'count_x32']+=1
            else: data=data.loc[data.epoch!=2]
            data.to_csv(path,index=False)
        elif case in ('wrong_scale_choice','wrong_initial_theta'):
            path=folder/'scale_block_state.csv'; data=pd.read_csv(path,float_precision='round_trip')
            data.loc[0,'offset' if case=='wrong_scale_choice' else 'theta']=5 if case=='wrong_scale_choice' else 5.9
            data.to_csv(path,index=False)
        elif case=='wrong_source_audit':
            path=folder/'history.json'; data=json.loads(path.read_text())
            data['epochs'][0]['gradient_checks']['shared_source_checks']['scale_offsets_learned']-=1
            write_json(path,data)
        elif case=='false_epoch100_claim':
            path=folder/'training_summary.json'; data=json.loads(path.read_text())
            data['full_100_epoch_training_completed']=True; write_json(path,data)
        elif case=='false_constant_accuracy':
            path=folder/'history.json'; data=json.loads(path.read_text())
            data['epochs'][0]['test_prediction_counts']['6']=[1000]+[0]*9; write_json(path,data)
        else:
            path=folder/'run_report.json'; data=json.loads(path.read_text())
            export=data['mx_exports']['last_epoch']['8' if case=='learned_E4_source' else '6']
            export[{'proxy_in_export':'fp32_scale_proxies_absent','learned_E4_source':'learned_shared_scale',
                    'wrong_packed_bytes':'packed_scale_choices_bytes'}[case]] = (False if case=='proxy_in_export' else True if case=='learned_E4_source' else 4080)
            write_json(path,data)
        before=raw_hashes(folder); run=ns.load_run(folder)
        errors=[x['Melding'] for x in run.issues if x['Niveau']=='FOUT']
        assert errors,case
        assert not run.pilot_complete and not run.reference_complete
        assert raw_hashes(folder)==before
        checks[case]={'expected_rejection':True,'messages':errors}
    return checks


def main(out):
    out.mkdir(parents=True,exist_ok=False)
    notebook_path=PACKAGE/'MX_triple_learned_scale10_pilot5_resultaten.ipynb'
    notebook=json.loads(notebook_path.read_text()); template_hash=hashlib.sha256(notebook_path.read_bytes()).hexdigest()
    assert all(c.get('execution_count') is None and not c.get('outputs') for c in notebook['cells'] if c['cell_type']=='code')
    assert sum(c['cell_type']=='code' for c in notebook['cells'])==16
    assert notebook['metadata']['scale_factor_choices']==list(ns.SCALE_FACTORS)
    expected_figures={'checkpoint_accuracy','accuracy_curves','objective_losses','timing','gpu_memory',
                      'prediction_diversity','scale_comparison_curves','scale_comparison_checkpoints',
                      'scale_choices','theta_distributions','scale_switches','scale_gradients','scale_boundaries','storage_cost'}
    results={}
    for name,count,collapse in [('synthetic_complete5',5,False),('synthetic_stopped2',2,False),
                                ('synthetic_constant_class5',5,True)]:
        folder=out/name/'input'; measured=make_fixture(folder,count,collapse); before=raw_hashes(folder)
        context,stdout=execute_cells(notebook,folder)
        run,figures,references=context['run'],context['figures'],context['references']
        assert run.synthetic and run.scales_safe and not run.reference_complete
        assert run.pilot_complete==(count==5), run.issues
        assert not [x for x in run.issues if x['Niveau'] in ('FOUT','RUNFOUT')],run.issues
        assert run.observed_best_epoch==2 and run.last_epoch==count
        assert len(run.metrics)==6*count and len(run.scale_epochs)==6*count
        assert len(run.scale_blocks)==4080*(count+1)
        assert math.isclose(ns.measured_completed_seconds(run),measured)
        table=ns.checkpoint_table(run)
        assert len(table)==6 and set(table.Rol)=={'last_epoch','best_E4M3_test'}
        best=table.loc[table.Rol=='best_E4M3_test']
        assert best.Epoch.eq(2).all()
        assert best['Testaccuracy [%]'].tolist()==([90,10,10] if collapse else [90,80,70])
        assert set(figures)==expected_figures
        for namefig,fig in figures.items():
            title=fig._suptitle.get_text() if fig._suptitle else fig.axes[0].get_title()
            assert 'SYNTHETISCHE CONTROLE' in title,(namefig,title)
        assert [len(ax.patches) for ax in figures['checkpoint_accuracy'].axes]==[3,3]
        assert [len(ax.lines) for ax in figures['accuracy_curves'].axes]==[3,3]
        assert all(max(line.get_xdata())==count for ax in figures['accuracy_curves'].axes for line in ax.lines)
        assert all(ref.safe and not ref.compatible for ref in references.values()),[(r.factor,r.issues) for r in references.values()]
        assert all(ref.test.epoch.max()==5 and ref.best_epoch(5)<=5 for ref in references.values())
        assert ns.comparison_table(run,references).empty
        assert not any(ax.lines for ax in figures['scale_comparison_curves'].axes)
        if count<5: assert 'Gecontroleerd gestopt' in ns.status_markdown(run)
        if collapse:
            assert run.predictions.loc[run.predictions.weight_bits!=8,'Constante voorspelling'].all()
            assert run.scale_epochs.choice_flips_during_epoch.eq(0).all()
            assert any(x['Niveau']=='UITKOMST' for x in run.issues)
        preview=out/name/'preview';preview.mkdir()
        for key,fig in figures.items(): fig.savefig(preview/(key+'.png'),dpi=110,bbox_inches='tight')
        (out/name/'notebook_stdout.txt').write_text(stdout)
        assert raw_hashes(folder)==before and not list(folder.glob('analysis_*'))
        results[name]={'status':'PASS','completed_epochs':count,'selected_common_E4_epoch':2,
                       'all_16_code_cells_executed':True,'all_14_figures_rendered':True,
                       'raw_inputs_unchanged':True,'real_reference_comparison_blocked':True}
        plt.close('all')
    full=out/'synthetic_complete5/input'
    negatives=negative_checks(out,full)
    check=out/'synthetic_check_only';check.mkdir()
    report=json.loads((full/'run_report.json').read_text())
    report.update(command='check',synthetic_checks_only=True,mx_exports={})
    write_json(check/'run_report.json',report)
    shutil.copyfile(PACKAGE/'notebook_support.py',check/'notebook_support.py')
    shutil.copytree(PACKAGE/'fixed_references',check/'fixed_references')
    before=raw_hashes(check); context,_=execute_cells(notebook,check)
    assert context['run'].test.empty and not context['run'].pilot_complete
    assert ns.checkpoint_table(context['run'])['Testaccuracy [%]'].isna().all()
    assert raw_hashes(check)==before
    results['check_only']={'status':'PASS','no_metrics_invented':True}
    # Construct explicitly synthetic comparison series. Different E4 maxima
    # prove that one early shared selection is computed separately per run.
    run=ns.load_run(full); refs={}
    for factor,corrects in [(32,[500,600,700,950,950]),(64,[700,950,850,800,900]),(None,[950,800,700,600,500])]:
        metric=run.metrics.copy()
        for epoch,correct in enumerate(corrects,1):
            at=(metric.phase=='test')&(metric.weight_bits==8)&(metric.epoch==epoch)
            metric.loc[at,['correct1','top1_percent','count_top1_percent']]=[correct,correct/10,correct/10]
        refs[factor]=ns.FixedReference(out/f'synthetic_only_scale{factor}',factor,metrics=metric,safe=True,compatible=True,
                                     issues=['SYNTHETIC ONLY; direct construction exercises plotting, not provenance.'])
    assert refs[32].best_epoch(5)==4 and refs[32].best_epoch(2)==2 and refs[64].best_epoch(5)==2
    table=ns.comparison_table(run,refs); assert len(table)==18
    assert table.loc[table.Controlepunt.str.startswith('Beste')&(table.Referentie=='Vast ×32'),'Epoch referentie'].eq(4).all()
    assert table.loc[table.Controlepunt.str.startswith('Beste'),'Epoch geleerd'].eq(2).all()
    preview=out/'synthetic_comparison_preview';preview.mkdir()
    fig=ns.plot_scale_comparison_checkpoints(run,refs)
    assert [len(ax.patches) for ax in fig.axes]==[12,12]
    fig.savefig(preview/'checkpoints.png',dpi=130,bbox_inches='tight')
    fig=ns.plot_scale_comparison_curves(run,refs)
    assert [len(ax.lines) for ax in fig.axes]==[4,4,4]
    fig.savefig(preview/'curves.png',dpi=130,bbox_inches='tight')
    stopped=ns.load_run(out/'synthetic_stopped2/input')
    early=ns.comparison_table(stopped,refs)
    assert early.loc[early.Controlepunt=='Epoch 5','Geleerd accuracy [%]'].isna().all()
    assert early.loc[early.Controlepunt.str.startswith('Beste') & early.Referentie.str.startswith('Vast'),'Epoch referentie'].eq(2).all()
    assert early.loc[early.Controlepunt.str.startswith('Beste') & early.Referentie.str.startswith('Geleerd'),'Epoch referentie'].eq(1).all()
    fig=ns.plot_scale_comparison_curves(stopped,refs)
    assert all(max(line.get_xdata())==2 for ax in fig.axes for line in ax.lines)
    plt.close('all')
    results['synthetic_comparison']={'status':'PASS','common_early_range_enforced':True,'no_future_best_leakage':True,
                                    'separate_E4_selected_epochs':{'learned':2,'fixed32':4,'fixed64':2,'binary':1}}
    # Pinned reference mutation is rejected even when someone recomputes its
    # manifest hash. Hardcoded report pins are independent of that manifest.
    mutated=out/'reference_pin_mutation';shutil.copytree(PACKAGE/'fixed_references',mutated)
    p=mutated/'scale32/run_report.json';changed=json.loads(p.read_text());changed['status']='BROKEN';write_json(p,changed)
    m=mutated/'scale32/REFERENCE.json';manifest=json.loads(m.read_text());manifest['files_sha256']['run_report.json']=hashlib.sha256(p.read_bytes()).hexdigest();write_json(m,manifest)
    checked=ns.load_fixed_references(run,mutated)
    assert not checked[32].safe and checked[64].safe
    results['reference_pin_mutation']={'status':'PASS','rehashed_mutation_rejected':True}
    # Optional figure saving gets a fresh folder and preserves every raw input.
    before=raw_hashes(full);fig={'checkpoint_accuracy':ns.plot_checkpoint_accuracy(run)}
    saved=ns.save_figures(fig,run)
    assert saved.parent==run.path and (saved/'analysis_manifest.json').is_file()
    assert raw_hashes(full)==before
    results['optional_save']={'status':'PASS','fresh_analysis_directory_only':True}
    assert hashlib.sha256(notebook_path.read_bytes()).hexdigest()==template_hash
    result={'status':'PASS','synthetic_fixture_only':True,'no_SVHN_training_or_accuracy_claim':True,
            'no_checkpoint_or_training_imports':True,'unexecuted_template_preserved':True,
            'tests':results,'negative_checks':negatives,'template_sha256':template_hash,
            'helper_sha256':hashlib.sha256((PACKAGE/'notebook_support.py').read_bytes()).hexdigest()}
    write_json(out/'notebook_validation_report.json',result)
    print(json.dumps(result,indent=2))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();main(args.out.resolve())
